/* Copyright (c) 2016 Nordic Semiconductor. All Rights Reserved.
 *
 * The information contained herein is property of Nordic Semiconductor ASA.
 * Terms and conditions of usage are described in detail in NORDIC
 * SEMICONDUCTOR STANDARD SOFTWARE LICENSE AGREEMENT.
 *
 * Licensees are granted free, non-transferable use of the information. NO
 * WARRANTY of ANY KIND is provided. This heading must NOT be removed from
 * the file.
 *
 */

#ifndef NFC_NDEF_MSG_PARSER_H__
#define NFC_NDEF_MSG_PARSER_H__

/**@file
 *
 * @defgroup nfc_ndef_parser NDEF message parser
 * @{
 * @ingroup  nfc_modules
 *
 * @brief    Parser for NFC NDEF messages and records.
 *
 * @defgroup nfc_ndef_msg_parser Parser for NDEF messages
 * @{
 * @ingroup  nfc_ndef_parser
 *
 * @brief    Parser for NFC NDEF messages.
 *
 */

#include <stdint.h>
#include "nfc_ndef_msg_parser_local.h"

/**
 * @brief Macro for calculating the memory size required for holding the
 * description of a message that consists of a certain number of NDEF records.
 *
 * @param[in] max_count_of_records Maximum number of records to hold.
 */
#define NFC_NDEF_PARSER_REQIRED_MEMO_SIZE_CALC(max_count_of_records)   \
    ((uint32_t)(max_count_of_records) <= 1) ?                          \
    (sizeof(parsed_ndef_msg_1_t) * (uint32_t)(max_count_of_records)) : \
    (sizeof(parsed_ndef_msg_1_t) + ((NFC_PARSER_M_DELTA) *((uint32_t)(max_count_of_records) - 1)))

/**
 * @brief   Function for parsing NFC NDEF messages.
 *
 * This function parses NDEF messages using NDEF binary record descriptors.
 *
 * @param[out] p_result_buf        Pointer to the buffer that will be used to hold
 *                                 the NDEF message descriptor. After parsing is completed successfully, the first address
 *                                 in the buffer is filled by the NDEF message descriptor
 *                                 (@ref nfc_ndef_msg_desc_t), which provides a full description of
 *                                 the parsed NDEF message.
 * @param[in,out] p_result_buf_len As input: size of the buffer specified by @p p_result_buf.
 *                                 As output: size of the reserved (used) part of the buffer specified by
 *                                 @p p_result_buf.
 * @param[in]    p_nfc_data        Pointer to the data to be parsed.
 * @param[in,out] p_nfc_data_len   As input: size of the NFC data in the @p p_nfc_data buffer. As output: size of the parsed message.
 *
 * @retval NRF_SUCCESS               If the function completed successfully.
 * @retval NRF_ERROR_NO_MEM          If the provided buffer is too small to hold a one-record message or
 *                                   the buffer is too small to hold the actual result of the parsing.
 * @retval NRF_ERROR_INVALID_LENGTH  If the expected message length is bigger than the amount of the provided input data.
 * @retval NRF_ERROR_INVALID_DATA    If the message is not a valid NDEF message.
 */
ret_code_t ndef_msg_parser(uint8_t  * const p_result_buf,
                           uint32_t * const p_result_buf_len,
                           uint8_t  * const p_nfc_data,
                           uint32_t * const p_nfc_data_len);

/**
 * @brief Function for printing the parsed contents of an NDEF message.
 *
 * @param[in] p_msg_desc Pointer to the descriptor of the message that should be printed.
 */
void ndef_msg_printout(nfc_ndef_msg_desc_t * const p_msg_desc);

/**
 * @}
 * @}
 */

#endif // NFC_NDEF_MSG_PARSER_H__


